Hello, thank you for purchasing this product. This folder contains world file and .schematic file of different versions

IMPORTANT!
Before loading the schematic: /gamerule randomTickSpeed 0 (because the leaves from trees can fall down)

Terms and Conditions:
1. By purchasing this product you automatically agree to the Terms of Service.
2. You may not resell, distribute, or claim this build as your own.
3. There are no refunds. All purchases are final due to the digital nature of the product.
4. We are not responsible if you accidentally delete or lose purchased build(s). We are not responsible for a refund or replacement.
5. These Terms of Service may change at any time without notification.